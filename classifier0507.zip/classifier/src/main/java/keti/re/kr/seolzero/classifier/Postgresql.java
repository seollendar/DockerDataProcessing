package keti.re.kr.seolzero.classifier;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.util.Date;
import java.util.Properties;
import java.util.TimeZone;

import com.jsoniter.any.Any;

public class Postgresql {
	private final String url;
	private final String user;
	private final String password;
	private Connection conn;
	private Statement stmnt;
	SimpleDateFormat format;

	Postgresql() {
		this.url = "jdbc:postgresql://postgres/spatiodata";
		this.user = "postgres";
		this.password = "keti123";
		try {
			this.conn = DriverManager.getConnection(url, user, password);
			this.stmnt = conn.createStatement();
		} catch (SQLException e) {
			System.out.println(e.getMessage());
		}

		format = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS");
		format.setTimeZone(TimeZone.getTimeZone("UTC"));
	}


	public void send(String ae, String container, Any conObject) {

		//			Double latitude = conObject.get("latitude").toDouble();
		//			Double longitude = conObject.get("longitude").toDouble();
		Double altitude = conObject.get("altitude").toDouble();
		//			Double velocity = conObject.get("velocity").toDouble();
		//			Double direction = conObject.get("direction").toDouble();
		//			String timestamp = conObject.get("time").toString();

		String sql = "INSERT INTO spatio (ae, container, latitude, longitude, altitude, velocity, direction, time, gps) "
				+ "VALUES " + "('" + ae + "', '" + container + "', " + conObject.get("latitude") + ", " + conObject.get("longitude") 
				+ ", " + altitude + ", "  + conObject.get("velocity") + ", " + conObject.get("direction") + ", '" + conObject.get("time") + "', "
				+ "ST_SetSRID(ST_MakePoint(" + conObject.get("longitude") + ", " + conObject.get("latitude") + "),4326))";
		System.out.println("sql: " + sql);
		try {
			stmnt.executeUpdate(sql);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}


}
