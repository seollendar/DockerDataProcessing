package keti.re.kr.seolzero.classifier;

import org.apache.ibatis.io.Resources;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.apache.kafka.clients.consumer.ConsumerRecords;
import org.apache.kafka.clients.consumer.KafkaConsumer;
import org.apache.kafka.common.TopicPartition;
import org.apache.kafka.common.errors.WakeupException;
//import org.apache.log4j.Logger;
import org.influxdb.dto.BatchPoints;
import org.influxdb.dto.Point;

import com.jsoniter.JsonIterator;
import com.jsoniter.any.Any;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.Properties;
import java.util.TimeZone;
import java.util.concurrent.TimeUnit;
import java.io.IOException;
import java.io.InputStream;
import java.io.Reader;
import java.sql.SQLException;
import java.text.ParseException;
import org.influxdb.InfluxDB;
import org.influxdb.InfluxDBFactory;
import org.influxdb.dto.Point;
import java.util.Properties;

public class ConsumerWorkerProperties implements Runnable {
	static InfluxDB influxDB = InfluxDBFactory.connect("http://influx:8086");
	static String dbName = "notiflow";
	
	private Properties prop;
	private String topic;
	private String threadName;
	private KafkaConsumer<String, String> consumer;
    private SimpleDateFormat format;    
    int message_count = 0;
	long startP, endP;
	private boolean flag = false;

	BatchPoints batchPoints;
	Point.Builder builder;
	
	ConsumerWorkerProperties(Properties prop, String topic, int number) {
		this.prop = prop;
		this.topic = topic;
		this.threadName = "consumer-thread-" + number;
		
		this.format = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS");
		this.format.setTimeZone(TimeZone.getTimeZone("UTC"));

	}

	public void run() {
		Postgresql Postgresql = new Postgresql();
	    Influxdb influx = new Influxdb();
	    
	    String resource = "config/container.properties";
	    Properties properties = new Properties();
        try {
            Reader reader = Resources.getResourceAsReader(resource);
            properties.load(reader);
		} catch (IOException e1) {
			e1.printStackTrace();
		}
        
		consumer = new KafkaConsumer<String, String>(prop);
		consumer.subscribe(Arrays.asList(topic));

		try {
			System.out.println("== classify Module == "+ threadName +" ==");

			while (true) {

				ConsumerRecords<String, String> records = consumer.poll(1000);
			    BatchPoints.Builder batchBuilder = BatchPoints
			    		.database(dbName)
						.retentionPolicy("autogen");

				for (ConsumerRecord<String, String> record : records) {
					
					message_count++;
					System.out.println("message_count"+ message_count);
					/*
					if(message_count >= 0 && !flag) {
						startP = System.currentTimeMillis();
						System.out.println("[START] "+ startP + " [" + threadName + "] >count: " + message_count);
						flag = true;
					}*/
					
					Any jsonObject = JsonIterator.deserialize(record.value());
					Any conObject = jsonObject.get("m2m:sgn").get("nev").get("rep").get("m2m:cin").get("con");
					System.out.println(threadName +" jsonObject: "+ jsonObject);
					
					/* split device AE, container */
					String sur = jsonObject.get("m2m:sgn").get("sur").toString();
					System.out.println("sur: "+ sur);
					
					String[] surSplitArray = sur.split("/");
					String AE = surSplitArray[4];        
					String container = surSplitArray[5]; 
//					String AE = surSplitArray[1];        
//					String container = surSplitArray[2]; 
					
					/*container가 properties에 등록된 location container인지*/
			        if(properties.containsKey(container)) { //container = location
			        	Postgresql.send(AE, container, conObject);
			        	Point point = influx.createPoint(AE, container, conObject);
			        	batchBuilder.point(point);
			        }else {//container = timeseries
			        	Point point = influx.createPoint(AE, container, conObject);
			        	batchBuilder.point(point);
			        	
			        }
			        
			        /*
					if(message_count == 20000) {
						endP = System.currentTimeMillis();
						System.out.println("  [END] " + endP + " [" + threadName +"] >count: " + message_count);
						System.out.println( "Time taken(ms): " + ( endP - startP )); 
					}*/

				}//for
				
			influxDB.write(batchBuilder.build());

			}//while

		} catch (WakeupException e) {
			System.out.println(threadName + " trigger WakeupException");
		} catch (org.json.simple.parser.ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			System.out.println(threadName + " gracefully shutdown");
			//consumer.close();
		}
	}

	public void shutdown() {
		consumer.wakeup();
	}


}
