package keti.re.kr.seolzero.classifier;

import java.io.IOException;
import java.util.Arrays;
import java.util.Properties;

import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.apache.kafka.clients.consumer.ConsumerRecords;
import org.apache.kafka.clients.consumer.KafkaConsumer;

import com.jsoniter.JsonIterator;
import com.jsoniter.any.Any;

public class PropertiesApp {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		LoadProperties loadProperties = new LoadProperties();
        // 프로퍼티 파일을 읽어들이고 해당 값을 출력해봅니다.
        try {
        	loadProperties.loadProp("C://eclipsework/classifier/SourceFolder/Containers.properties");
		} catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
        Properties properties = loadProperties.getProperties();
        System.out.println("get: "+properties);
        

	}

}
