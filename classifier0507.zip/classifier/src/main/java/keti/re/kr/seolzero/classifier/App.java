package keti.re.kr.seolzero.classifier;


import java.sql.SQLException;

import org.json.simple.parser.ParseException;

import com.jsoniter.JsonIterator;
import com.jsoniter.any.Any;
/**
 * Hello world!
 *
 */
public class App 
{
	public static void main( String[] args ) throws ParseException, java.text.ParseException, SQLException
	{
		String ae = "location";
		String container = "scnt-location";
		//Any jsonObject = JsonIterator.deserialize("{\"con\" : {\"latitude\": 27, \"longitude\": 127, \"altitude\": 1,\"velocity\": 1,\"direction\": 0,\"time\": \"2021-04-19T04:03:13.013\" }}");
		Any jsonObject = JsonIterator.deserialize("{\"con\" : {\"latitude\": 27.123123, \"longitude\": 127.123123, \"velocity\": 1,\"direction\": 0,\"time\": \"2021-04-19T09:19:13.013\" }}");
		System.out.println(jsonObject);
		Any conObject = jsonObject.get("con");

		Influxdb j = new Influxdb();
		j.send(ae, container, conObject);
		
//		Postgresql p = new Postgresql();
//		p.send(ae, container, conObject);
	}
}
