package keti.seolzero.JavaPreprocessing;

import java.util.Date;

public class PreprocFunction {



	/*Speed*/
	public static double getSpeed(double previousLatitude, double previousLongitude, Date previousTimeParse, double currentLatitude, double currentLongitude, Date currentTimeParse) {
		double distancePerM = getDistance(previousLatitude, previousLongitude, currentLatitude, currentLongitude);//이동거리(m)
		long TimeDiff = (currentTimeParse.getTime() - previousTimeParse.getTime())/1000; // 단위:s
		double computevelocity = computespeed(TimeDiff, distancePerM);//이동속도

		return computevelocity;
	}

	/*Distance*/
	public static double getDistance(double previousLatitude, double previousLongitude, double currentLatitude, double currentLongitude) {
		double p = 0.017453292519943295;    // Math.PI / 180
		double a = 0.5 - Math.cos((currentLatitude - previousLatitude) * p)/2 + Math.cos(previousLatitude * p) * Math.cos(currentLatitude * p) * (1 - Math.cos((currentLongitude - previousLongitude) * p))/2;
		return (12742 * Math.asin(Math.sqrt(a))*1000);
	} 

	public static double computespeed (long timediff, double distancediff){
		double tspeed;
		if(distancediff == 0){
			tspeed = 0;  
		}else{
			tspeed = distancediff / timediff;
		}

		return tspeed;
	} 

	/*bearing*/
	public static double getDirection(double lat1, double lon1, double lat2, double lon2){
		double lat1_rad = convertdecimaldegreestoradians(lat1);
		double lat2_rad = convertdecimaldegreestoradians(lat2);
		double lon_diff_rad = convertdecimaldegreestoradians(lon2-lon1);
		double y = Math.sin(lon_diff_rad) * Math.cos(lat2_rad);
		double x = Math.cos(lat1_rad) * Math.sin(lat2_rad) - Math.sin(lat1_rad) * Math.cos(lat2_rad) * Math.cos(lon_diff_rad);
		return (convertradianstodecimaldegrees(Math.atan2(y,x)) + 360) % 360;
	}   

	/*decimal degree -> radian*/
	public static double convertdecimaldegreestoradians(double deg){
		return (deg * Math.PI / 180);
	}

	/*decimal radian -> degree*/
	public static double convertradianstodecimaldegrees(double rad){
		return (rad * 180 / Math.PI);
	}      

	
	
	
}
