package keti.re.kr.seolzero.classifier;

import org.apache.ibatis.io.Resources;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.apache.kafka.clients.consumer.ConsumerRecords;
import org.apache.kafka.clients.consumer.KafkaConsumer;
import org.apache.kafka.common.TopicPartition;
import org.apache.kafka.common.errors.WakeupException;
import org.influxdb.dto.BatchPoints;
import org.influxdb.dto.Point;

import com.jsoniter.JsonIterator;
import com.jsoniter.any.Any;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.Properties;
import java.util.TimeZone;
import java.util.concurrent.TimeUnit;
import java.io.IOException;
import java.io.InputStream;
import java.io.Reader;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.ParseException;
import org.influxdb.InfluxDB;
import org.influxdb.InfluxDBFactory;
import org.influxdb.dto.Point;
import java.util.Properties;

public class ConsumerWorkerPropertiesBatch implements Runnable {
	static InfluxDB influxDB = InfluxDBFactory.connect("http://10.0.2.5:8086");
	static String dbName = "notiflow";

	private final String url = "jdbc:postgresql://10.0.2.4/spatiodata";
	private final String user = "postgres";
	private final String password = "keti123";
	private Connection conn;
	private Statement stmnt;

	private Properties prop;
	private String topic;
	private String threadName;
	private KafkaConsumer<String, String> consumer;
	private SimpleDateFormat format;    

	BatchPoints batchPoints;
	Point.Builder builder;

	ConsumerWorkerPropertiesBatch(Properties prop, String topic, int number) {
		this.prop = prop;
		this.topic = topic;
		this.threadName = "consumer-thread-" + number;

		this.format = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS");
		this.format.setTimeZone(TimeZone.getTimeZone("UTC"));
		try {
			this.conn = DriverManager.getConnection(url, user, password);
			this.stmnt = conn.createStatement();
		} catch (SQLException e) {			
			System.out.println("postgres E: " + e.getMessage());
		}

	}

	public void run() {
		Postgresql Postgresql = new Postgresql();
		Influxdb influx = new Influxdb();

		String resource = "config/container.properties";
		Properties properties = new Properties();
		try {
			Reader reader = Resources.getResourceAsReader(resource);
			properties.load(reader);
		} catch (IOException e1) {
			e1.printStackTrace();
		}

		consumer = new KafkaConsumer<String, String>(prop);
		consumer.subscribe(Arrays.asList(topic));

		try {
			System.out.println("== classify Module == "+ threadName +" ==");

			while (true) {

				ConsumerRecords<String, String> records = consumer.poll(1000);
				BatchPoints.Builder batchBuilder = BatchPoints
						.database(dbName)
						.retentionPolicy("autogen");

				for (ConsumerRecord<String, String> record : records) {

					Any jsonObject = JsonIterator.deserialize(record.value());
					Any conObject = jsonObject.get("m2m:sgn").get("nev").get("rep").get("m2m:cin").get("con");
					
					/* split device AE, container */
					String sur = jsonObject.get("m2m:sgn").get("sur").toString();

					String[] surSplitArray = sur.split("/");
					String AE = surSplitArray[4];        
					String container = surSplitArray[5]; 
					
					/*container가 properties에 등록된 location container인지*/
					if(properties.containsKey(container)) { //container = location
						String sql = Postgresql.createSQL(AE, container, conObject);
						stmnt.addBatch(sql);
						Point point = influx.createPoint(AE, container, conObject);
						batchBuilder.point(point);
						
					}else {//container = timeseries
						Point point = influx.createPoint(AE, container, conObject);
						batchBuilder.point(point);

					}


				}//for

				stmnt.executeBatch();
				influxDB.write(batchBuilder.build());

			}//while

		} catch (WakeupException e) {
			System.out.println(threadName + " trigger WakeupException");
		} catch (org.json.simple.parser.ParseException e) {
			e.printStackTrace();
		} catch (ParseException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			System.out.println(threadName + " gracefully shutdown");
		}
	}

	public void shutdown() {
		consumer.wakeup();
	}


}
