package keti.re.kr.seolzero.classifier;

import org.apache.kafka.clients.consumer.ConsumerConfig;
import org.apache.kafka.common.serialization.StringDeserializer;

import java.util.ArrayList;
import java.util.List;
import java.util.Properties;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class ConsumerWithMultiThread {
	private static String TOPIC_NAME = "notifi";
	private static String GROUP_ID = "multiThreadNotiClassifi";
	private static String BOOTSTRAP_SERVERS = "10.0.2.8:9093";
	private static int CONSUMER_COUNT = 3;
	private static List<ConsumerWorkerPropertiesBatch> workerThreads = new ArrayList<ConsumerWorkerPropertiesBatch>();
	
	public static void main(String[] args) {
		Runtime.getRuntime().addShutdownHook(new ShutdownThread());
		Properties configs = new Properties();
		configs.put(ConsumerConfig.BOOTSTRAP_SERVERS_CONFIG, BOOTSTRAP_SERVERS);
		configs.put(ConsumerConfig.GROUP_ID_CONFIG, GROUP_ID);
		configs.put(ConsumerConfig.KEY_DESERIALIZER_CLASS_CONFIG, StringDeserializer.class.getName());
		configs.put(ConsumerConfig.VALUE_DESERIALIZER_CLASS_CONFIG, StringDeserializer.class.getName());
		configs.put(ConsumerConfig.ENABLE_AUTO_COMMIT_CONFIG, false);
		configs.put(ConsumerConfig.AUTO_OFFSET_RESET_CONFIG, "earliest");

		ExecutorService executorService = Executors.newCachedThreadPool();
		for (int i = 0; i < CONSUMER_COUNT; i++) {
			ConsumerWorkerPropertiesBatch worker = new ConsumerWorkerPropertiesBatch(configs, TOPIC_NAME, i);
			workerThreads.add(worker);
			executorService.execute(worker);

		}
	}

	static class ShutdownThread extends Thread {
		public void run() {
			System.out.println("Bye");
		}
	}
}
