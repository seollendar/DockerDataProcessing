package keti.re.kr.seolzero.classifier;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.util.Date;
import java.util.Properties;
import java.util.TimeZone;

import com.jsoniter.any.Any;

public class Postgresql {

	public String createSQL(String ae, String container, Any conObject) {

		Double altitude = conObject.get("altitude").toDouble();
		String sql = "INSERT INTO spatio (ae, container, latitude, longitude, altitude, velocity, direction, time, gps) "
				+ "VALUES " + "('" + ae + "', '" + container + "', " + conObject.get("latitude") + ", " + conObject.get("longitude") 
				+ ", " + altitude + ", "  + conObject.get("velocity") + ", " + conObject.get("direction") + ", '" + conObject.get("time") + "', "
				+ "ST_SetSRID(ST_MakePoint(" + conObject.get("longitude") + ", " + conObject.get("latitude") + "),4326))";
		return sql;

	}

}
