package keti.seolzero.JavaPreprocessing;
import java.io.IOException;
import java.text.ParseException;

import org.json.JSONObject;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

//import com.dslplatform.json.DslJson;
//import com.dslplatform.json.JsonWriter;

import com.jsoniter.JsonIterator;
import com.jsoniter.any.Any;


//import com.google.gson.Gson;

public class jsonParser {

   public static void main(String[] args) throws ParseException, Exception  {

      String JSON_TEST_DATA 
      = "{\"m2m:sgn\":{\"nev\":{\"rep\":{\"m2m:cin\":{\"ty\":4,\"ri\":\"cin00S02f9ecfd6-35ef-451e-8672-09ab3ec09a141603350091457\",\"rn\":\"cin-S02f9ecfd6-35ef-451e-8672-09ab3ec09a141603350091457\",\"pi\":\"cnt00000000000001951\",\"ct\":\"20201022T160131\",\"lt\":\"20201022T160131\",\"et\":\"20201121T160131\",\"st\":903335,\"cr\":\"SS01228427453\",\"cnf\":\"application/json\",\"cs\":155,\"con\":{\"i\":992,\"latitude\":28.4966018,\"longitude\":129.0953344,\"altitude\":12.934,\"velocity\":0,\"direction\":0,\"time\":\"2020-12-01T04:42:39\",\"position_fix\":1,\"satelites\":0,\"state\":\"ON\"}}},\"om\":{\"op\":1,\"org\":\"SS01228427453\"}},\"vrq\":false,\"sud\":false,\"sur\":\"/~/CB00061/smartharbor/dt1/scnt-location/sub-S01228427453_user\",\"cr\":\"SS01228427453\"}}";
      //
      //      /*JsonORG*/
      //      JSONObject notiObj = new JSONObject(JSON_TEST_DATA);
      //      JSONObject postObject = notiObj.getJSONObject("m2m:sgn").getJSONObject("nev").getJSONObject("rep").getJSONObject("m2m:cin").getJSONObject("con");
      //      String conData = postObject.getString("latitude");
      //      System.out.println(conData);
      
      /*Jackson*/
      ObjectMapper mapper = new ObjectMapper();
      JsonNode node = mapper.readTree(JSON_TEST_DATA);
      Object content = node.get("m2m:sgn").get("nev").get("rep").get("m2m:cin").get("con"); //.ObjectNode
      Double latitude = node.get("m2m:sgn").get("nev").get("rep").get("m2m:cin").get("con").get("latitude").asDouble(); 
      System.out.println(content.getClass().getName());
      /*JsonIterator*/
//      JsonIterator iterator = JsonIterator.parse(JSON_TEST_DATA);
//      String field = iterator.readObject();
//      System.out.println(field);


      //String jsonString = "{'a':1,'b':'text'}".replaceAll("'", "\"");
//      Any jsonObject = JsonIterator.deserialize(JSON_TEST_DATA);
//      Object con = jsonObject.get("m2m:sgn").get("nev").get("rep").get("m2m:cin").get("con");
//      Double location = jsonObject.get("m2m:sgn").get("nev").get("rep").get("m2m:cin").get("con").get("latitude").toDouble();
//      //String text = jsonObject.get("time").toString();
//      System.out.println(con.getClass().getName());
//      System.out.println(con);

      /*DslJson*/
      //      DslJson<Object> dslJson = new DslJson<Object>();
      //      JsonWriter writer = dslJson.newWriter();
      //      dslJson.



      //      Gson gson = new Gson();
      //      Outermost outermost = gson.fromJson(JSON_TEST_DATA, Outermost.class);
      //      System.out.println("data jsonparsing: \n"+ outermost);
      //      
      //        if(outermost != null){
      //            Double latitude = outermost.m2msgn.nev.rep.m2mcin.con.latitude;
      //            System.out.println("latitude: "+ latitude);
      //        }else {
      //           System.out.println("null");
      //        }

      //      String StringconData = postObject.toString();
      //      ConObjectData jsonConData = gson.fromJson(conData, ConObjectData.class);
      //      System.out.println("data jsonparsing: \n"+ jsonConData.altitude);


   }

}