package keti.seolzero.JavaPreprocessing;

import org.apache.kafka.clients.consumer.ConsumerConfig;
import org.apache.kafka.common.serialization.StringDeserializer;

import java.util.ArrayList;
import java.util.List;
import java.util.Properties;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class ConsumerWithMultiThread {
	private static String TOPIC_NAME = "notifi3"; 
	private static String GROUP_ID = "multiThreadJedisPipe";
	private static String BOOTSTRAP_SERVERS = "kafka:9092"; //"10.252.73.143:9093"
	private static int CONSUMER_COUNT = 3;
	//	private static List<ConsumerWorker> workerThreads = new ArrayList<ConsumerWorker>();
	//	private static List<ConsumerWorkerJedis> workerThreads = new ArrayList<ConsumerWorkerJedis>();
	//	private static List<ConsumerWorkerJedisPipiline> workerThreads = new ArrayList<ConsumerWorkerJedisPipiline>();
	//	private static List<ConsumerWorkerHashmap> workerThreads = new ArrayList<ConsumerWorkerHashmap>();
	//	private static List<ConsumerWorkerJedisPipeline> workerThreads = new ArrayList<ConsumerWorkerJedisPipeline>();
	//	private static List<ConsumerWorkerJedisPipelineInfluxDB> workerThreads = new ArrayList<ConsumerWorkerJedisPipelineInfluxDB>();
	private static List<ConsumerWorkerJedisPipelineBatchInfluxDB> workerThreads = new ArrayList<ConsumerWorkerJedisPipelineBatchInfluxDB>();


	public static void main(String[] args) {
		Runtime.getRuntime().addShutdownHook(new ShutdownThread());
		Properties configs = new Properties();
		configs.put(ConsumerConfig.BOOTSTRAP_SERVERS_CONFIG, BOOTSTRAP_SERVERS);
		configs.put(ConsumerConfig.GROUP_ID_CONFIG, GROUP_ID);
		configs.put(ConsumerConfig.KEY_DESERIALIZER_CLASS_CONFIG, StringDeserializer.class.getName());
		configs.put(ConsumerConfig.VALUE_DESERIALIZER_CLASS_CONFIG, StringDeserializer.class.getName());
		configs.put(ConsumerConfig.ENABLE_AUTO_COMMIT_CONFIG, false);
		configs.put(ConsumerConfig.AUTO_OFFSET_RESET_CONFIG, "earliest");

		ExecutorService executorService = Executors.newCachedThreadPool();
		for (int i = 0; i < CONSUMER_COUNT; i++) {
			//			ConsumerWorker worker = new ConsumerWorker(configs, TOPIC_NAME, i);
			//			ConsumerWorkerJedis worker = new ConsumerWorkerJedis(configs, TOPIC_NAME, i);
			//			ConsumerWorkerJedisPipiline worker = new ConsumerWorkerJedisPipiline(configs, TOPIC_NAME, i);
			//			ConsumerWorkerHashmap worker = new ConsumerWorkerHashmap(configs, TOPIC_NAME, i);
			//			ConsumerWorkerJedisPipeline worker = new ConsumerWorkerJedisPipeline(configs, TOPIC_NAME, i);
			//			ConsumerWorkerJedisPipelineInfluxDB worker = new ConsumerWorkerJedisPipelineInfluxDB(configs, TOPIC_NAME, i);
			ConsumerWorkerJedisPipelineBatchInfluxDB worker = new ConsumerWorkerJedisPipelineBatchInfluxDB(configs, TOPIC_NAME, i);

			workerThreads.add(worker);
			executorService.execute(worker);

		}
	}

	static class ShutdownThread extends Thread {
		public void run() {
			//workerThreads.forEach(ConsumerWorker::shutdown); //error
			System.out.println("Bye");
		}
	}
}