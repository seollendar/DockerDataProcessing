package keti.seolzero.JavaPreprocessing;


import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.apache.kafka.clients.consumer.ConsumerRecords;
import org.apache.kafka.clients.consumer.KafkaConsumer;
import org.apache.kafka.common.TopicPartition;
import org.apache.kafka.common.errors.WakeupException;
import org.apache.log4j.Logger;
import org.json.JSONObject;

import java.time.Duration;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.concurrent.TimeUnit;
import java.util.Properties;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import redis.clients.jedis.Jedis;
import redis.clients.jedis.JedisPool;
import redis.clients.jedis.JedisPoolConfig;
import redis.clients.jedis.Pipeline;
import redis.clients.jedis.Response;



public class ConsumerWorkerJedisPipiline implements Runnable {
	private Properties prop;
	private String topic;
	private String threadName;
	private KafkaConsumer<String, String> consumer;
	private boolean flag = false;
	List<Object> kafkaRecords = new ArrayList<Object>();
	int message_count = 0;
	long startP;
	long endP;

	ConsumerWorkerJedisPipiline(Properties prop, String topic, int number) {
		this.prop = prop;
		this.topic = topic;
		this.threadName = "consumer-thread-" + number;
	}

	public void run() {
//		final Logger logger = Logger.getLogger(ConsumerWorkerHashmap.class);
		consumer = new KafkaConsumer<String, String>(prop);
		consumer.subscribe(Arrays.asList(topic));

		SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS");

		/*REDIS*/
		JedisPoolConfig jedisPoolConfig = new JedisPoolConfig();
		JedisPool pool = new JedisPool(jedisPoolConfig, "127.0.0.1", 6379);

		try {
			System.out.println("== Pre-processing Module == "+ threadName +" ==");

			while (true) {

				ConsumerRecords<String, String> records = consumer.poll(100);

				Jedis jedis = pool.getResource();
				Pipeline pipeline = jedis.pipelined();
				Pipeline pipeline2 = jedis.pipelined();

				for (ConsumerRecord<String, String> record : records) {
					String recordOfKafka = record.value();
					JSONObject notiObj = new JSONObject(recordOfKafka);
					kafkaRecords.add(notiObj);
					JSONObject conObject = notiObj.getJSONObject("m2m:sgn").getJSONObject("nev").getJSONObject("rep").getJSONObject("m2m:cin").getJSONObject("con");

					/* split device AE, container */
					String sur = notiObj.getJSONObject("m2m:sgn").getString("sur");
					String[] surSplitArray = sur.split("/");
					String AE = surSplitArray[4];        
					String container = surSplitArray[5]; 

					pipeline.get("previousDa_"+AE);

				}//for

				List<Object> results = pipeline.syncAndReturnAll();

				for(int i=0; i< results.size(); i++){ 

					message_count++;
					//            	logger.info("["+message_count+"] " + threadName);
					if(message_count >= 50000 && !flag) {
						startP = System.currentTimeMillis();
						System.out.println("[START] "+ startP + " [" + threadName + "] >count: " + message_count);
//						logger.info("[START] "+ startP + "[threadNum " + threadName + " ] count: " + message_count);
						flag = true;
					}

					if (results.get(i) == null) {

						JSONObject kafkaRecordObj = (JSONObject) kafkaRecords.get(i);
						JSONObject kafkaRecordConObject = kafkaRecordObj.getJSONObject("m2m:sgn").getJSONObject("nev").getJSONObject("rep").getJSONObject("m2m:cin").getJSONObject("con");
						String sur = kafkaRecordObj.getJSONObject("m2m:sgn").getString("sur");
						String[] surSplitArray = sur.split("/");
						String AE = surSplitArray[4];        
						String container = surSplitArray[5]; 

						pipeline2.set("previousDa_"+AE, kafkaRecordConObject.toString());    

					}else {

						/*previousData*/
						String jsonResponse = results.get(i).toString();
						JSONObject resObj = new JSONObject(jsonResponse);
						double previousLatitude = resObj.getDouble("latitude");
						double previousLongitude = resObj.getDouble("longitude");
						int previousI = resObj.getInt("i");
						String previousTime = resObj.getString("time");         
						Date previousTimeParse = null;
						try {
							previousTimeParse = format.parse(previousTime);
						} catch (ParseException e) {
							e.printStackTrace();
						}


						/*CurrentData*/
						JSONObject kafkaRecordObj = (JSONObject) kafkaRecords.get(i);
						JSONObject kafkaRecordConObject = kafkaRecordObj.getJSONObject("m2m:sgn").getJSONObject("nev").getJSONObject("rep").getJSONObject("m2m:cin").getJSONObject("con");
						double currentLatitude = kafkaRecordConObject.getDouble("latitude");
						double currentLongitude = kafkaRecordConObject.getDouble("longitude");
						int currentI = kafkaRecordConObject.getInt("i");
						String currentTime = kafkaRecordConObject.getString("time");
						Date currentTimeParse = null;
						try {
							currentTimeParse = format.parse(currentTime);
						} catch (ParseException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}

						/* split device AE, container */
						String sur = kafkaRecordObj.getJSONObject("m2m:sgn").getString("sur");
						String[] surSplitArray = sur.split("/");
						String AE = surSplitArray[4];        
						String container = surSplitArray[5]; 

						//                  System.out.println("["+i+"] "+ "previousI: "+ previousI +" currentI: "+ currentI + " previousLatitude: " + previousLatitude + " previousLongitude: " + previousLongitude + " previousTimeParse: " + previousTimeParse + " currentLatitude: " + currentLatitude + " currentLongitude: " + currentLongitude + " currentTimeParse: " + currentTimeParse);

						/*preprocessing vectorizing*/
						double preprocessingSpeed = getSpeed(previousLatitude, previousLongitude, previousTimeParse, currentLatitude, currentLongitude, currentTimeParse);
						double preprocessingDistance = getDistance(previousLatitude, previousLongitude, currentLatitude, currentLongitude);
						double preprocessingDirection = getDirection(previousLatitude, previousLongitude, currentLatitude, currentLongitude);
						//                  System.out.println("-Speed "+ preprocessingSpeed + "\n-Distance: "+ preprocessingDistance + "\n-Direction: "+ preprocessingDirection);
//						logger.info("[AE]: "+ AE + "["+i+"] "+ "previousI: "+ previousI +" currentI: "+ currentI                             
//								+ "\n    -[previousData]   Latitude: " + previousLatitude + " Longitude: " + previousLongitude + " Time: " + previousTimeParse
//								+ "\n    -[currentData]     Latitude: " + currentLatitude + " Longitude: " + currentLongitude + " Time" + currentTimeParse
//								+ "\n    -[Preprocessing]  Speed(m/s) "+ preprocessingSpeed + ", Distance(m): "+ preprocessingDistance + ", Direction: "+ preprocessingDirection);

						pipeline2.set("previousDa_"+AE, kafkaRecordConObject.toString());   

					}

					if(message_count >= 100000) {
						endP = System.currentTimeMillis();
						System.out.println("  [END] " + endP + " [" + threadName +"] >count: " + message_count);
						System.out.println( "Time taken(ms): " + ( endP - startP )); 
//						logger.info("[END] " + endP  + "[threadNum " + threadName + " ] count: " + message_count);
//						logger.info("Time taken(ms): " + ( endP - startP ));
					}

				}//for
				kafkaRecords.clear();
				pipeline2.sync();
				jedis.close();

			}//while

		} catch (WakeupException e) {
			System.out.println(threadName + " trigger WakeupException");
		} finally {
			System.out.println(threadName + " gracefully shutdown");
			//consumer.close();
		}
	}

	public void shutdown() {
		consumer.wakeup();
	}




	/*Speed*/
	public static double getSpeed(double previousLatitude, double previousLongitude, Date previousTimeParse, double currentLatitude, double currentLongitude, Date currentTimeParse) {
		double distancePerM = getDistance(previousLatitude, previousLongitude, currentLatitude, currentLongitude);//이동거리(m)
		long TimeDiff = (currentTimeParse.getTime() - previousTimeParse.getTime())/1000; // 단위:s
		double computevelocity = computespeed(TimeDiff, distancePerM);//이동속도

		return computevelocity;
	}

	/*Distance*/
	public static double getDistance(double previousLatitude, double previousLongitude, double currentLatitude, double currentLongitude) {
		double p = 0.017453292519943295;    // Math.PI / 180
		double a = 0.5 - Math.cos((currentLatitude - previousLatitude) * p)/2 + Math.cos(previousLatitude * p) * Math.cos(currentLatitude * p) * (1 - Math.cos((currentLongitude - previousLongitude) * p))/2;
		return (12742 * Math.asin(Math.sqrt(a))*1000);
	}

	/*bearing*/
	public static double getDirection(double lat1, double lon1, double lat2, double lon2){
		double lat1_rad = convertdecimaldegreestoradians(lat1);
		double lat2_rad = convertdecimaldegreestoradians(lat2);
		double lon_diff_rad = convertdecimaldegreestoradians(lon2-lon1);
		double y = Math.sin(lon_diff_rad) * Math.cos(lat2_rad);
		double x = Math.cos(lat1_rad) * Math.sin(lat2_rad) - Math.sin(lat1_rad) * Math.cos(lat2_rad) * Math.cos(lon_diff_rad);
		return (convertradianstodecimaldegrees(Math.atan2(y,x)) + 360) % 360;
	}    

	public static double computespeed (long timediff, double distancediff){
		double tspeed;
		if(distancediff == 0){
			tspeed = 0;  
		}else{
			tspeed = distancediff / timediff;
		}

		return tspeed;
	} 

	/*decimal degree -> radian*/
	public static double convertdecimaldegreestoradians(double deg){
		return (deg * Math.PI / 180);
	}

	/*decimal radian -> degree*/
	public static double convertradianstodecimaldegrees(double rad){
		return (rad * 180 / Math.PI);
	}      


}