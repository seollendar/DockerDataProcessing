package keti.seolzero.JavaPreprocessing;

import org.apache.ibatis.io.Resources;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.apache.kafka.clients.consumer.ConsumerRecords;
import org.apache.kafka.clients.consumer.KafkaConsumer;
import org.apache.kafka.common.TopicPartition;
import org.apache.kafka.common.errors.WakeupException;
import org.apache.log4j.Logger;
import org.influxdb.dto.BatchPoints;
import org.influxdb.dto.Point;

import com.jsoniter.JsonIterator;
import com.jsoniter.any.Any;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.Properties;
import java.util.TimeZone;
import java.util.concurrent.TimeUnit;
import java.io.IOException;
import java.io.Reader;
import java.text.ParseException;
import redis.clients.jedis.Jedis;
import redis.clients.jedis.JedisPool;
import redis.clients.jedis.JedisPoolConfig;
import redis.clients.jedis.Pipeline;
import org.influxdb.InfluxDB;
import org.influxdb.InfluxDBFactory;
import org.influxdb.dto.Point;



public class ConsumerWorkerJedisPipelineBatchInfluxDB implements Runnable {
	private Properties prop;
	static InfluxDB influxDB = InfluxDBFactory.connect("http://10.252.73.238:8086");
	static String dbName = "dbclass";
	//BatchPoints batchPoints = BatchPoints.database(dbName).retentionPolicy("autogen").build();

	private String topic;
	private String threadName;
	private KafkaConsumer<String, String> consumer;
	List<Object> kafkaRecords = new ArrayList<Object>();

	int message_count = 0;
	long startP, endP;
	private boolean flag = false;


	ConsumerWorkerJedisPipelineBatchInfluxDB(Properties prop, String topic, int number) {
		this.prop = prop;
		this.topic = topic;
		this.threadName = "consumer-thread-" + number;

	}

	public void run() {
		//final Logger logger = Logger.getLogger(ConsumerWorkerHashmap.class);
		consumer = new KafkaConsumer<String, String>(prop);
		consumer.subscribe(Arrays.asList(topic));

		SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS");
		format.setTimeZone(TimeZone.getTimeZone("UTC"));

		String resource = "config/container.properties";
		Properties properties = new Properties();
		try {
			Reader reader = Resources.getResourceAsReader(resource);
			properties.load(reader);
		} catch (IOException e1) {
			e1.printStackTrace();
		}

		/*REDIS*/
		JedisPoolConfig jedisPoolConfig = new JedisPoolConfig();
		JedisPool pool = new JedisPool(jedisPoolConfig, "redis", 6379);

		try {
			System.out.println("== Pre-processing Module == "+ threadName +" ==");

			while (true) {

				ConsumerRecords<String, String> records = consumer.poll(100);

				Jedis jedis = pool.getResource();
				Pipeline pipeline = jedis.pipelined();
				Pipeline pipeline2 = jedis.pipelined();
				BatchPoints batchPoints = BatchPoints.database(dbName).retentionPolicy("autogen").build();

				for (ConsumerRecord<String, String> record : records) {

					Any jsonObject = JsonIterator.deserialize(record.value());
					//Object conObject = jsonObject.get("m2m:sgn").get("nev").get("rep").get("m2m:cin").get("con");
					//logger.info("[conObject] : "+ conObject);

					/* split device AE, container */
					String sur = jsonObject.get("m2m:sgn").get("sur").toString();
					String[] surSplitArray = sur.split("/");
					
//					String AE = surSplitArray[4];        
//					String container = surSplitArray[5]; 
					String AE = surSplitArray[1];        
					String container = surSplitArray[2]; 
					System.out.println("sur: " + surSplitArray + "AE: " + AE);
					
					if(properties.containsKey(container)) {
						kafkaRecords.add(jsonObject);
						pipeline.get("previous_"+AE);
					}
//					else {
//						System.out.println("not a location container");
//					}
				}//for

				List<Object> results = pipeline.syncAndReturnAll();

				for(int i=0; i< results.size(); i++){ 

					message_count++;
					//					System.out.println("["+message_count+"] ");
					if(message_count >= 500 && !flag) {
						startP = System.currentTimeMillis();
						System.out.println("[START] "+ startP + " [" + threadName + "] >count: " + message_count);
						//logger.info("[START] "+ startP + "[threadNum " + threadName + " ] count: " + message_count);
						flag = true;
					}

					if (results.get(i) == null) {

						Any kafkaRecordObj = (Any) kafkaRecords.get(i);
						Object kafkaRecordConObject = kafkaRecordObj.get("m2m:sgn").get("nev").get("rep").get("m2m:cin").get("con");
						String sur = kafkaRecordObj.get("m2m:sgn").get("sur").toString();
						String[] surSplitArray = sur.split("/");
//						String AE = surSplitArray[4];
						String AE = surSplitArray[1];
						
						pipeline2.set("previous_"+AE, kafkaRecordConObject.toString());    

					}else {

						/*previousData*/
						Any PreviousConObject = JsonIterator.deserialize((String) results.get(i));
						double previousLatitude = PreviousConObject.get("latitude").toDouble();
						double previousLongitude = PreviousConObject.get("longitude").toDouble();
						String previousTime = PreviousConObject.get("time").toString();
						Date previousTimeParse = null;
						try {
							previousTimeParse = format.parse(previousTime);
						} catch (ParseException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}						
						Any previousI = PreviousConObject.get("i");    		// just for check. please remove after test

						/*CurrentData*/
						Any kafkaRecordObj = (Any) kafkaRecords.get(i);
						Any kafkaRecordConObject = kafkaRecordObj.get("m2m:sgn").get("nev").get("rep").get("m2m:cin").get("con");
						double currentLatitude = kafkaRecordConObject.get("latitude").toDouble();
						double currentLongitude = kafkaRecordConObject.get("longitude").toDouble();
						String currentTime = kafkaRecordConObject.get("time").toString();
						Date currentTimeParse = null;
						try {
							currentTimeParse = format.parse(currentTime);
						} catch (ParseException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
						Any currentI = kafkaRecordConObject.get("i");   	// just for check. please remove after test


						/* split device AE, container */
						String sur = kafkaRecordObj.get("m2m:sgn").get("sur").toString();
						String[] surSplitArray = sur.split("/");
//						String AE = surSplitArray[4];        
//						String container = surSplitArray[5]; 
						String AE = surSplitArray[1];        
						String container = surSplitArray[2]; 


						/*preprocessing vectorizing*/
						double preprocessingSpeed = PreprocFunction.getSpeed(previousLatitude, previousLongitude, previousTimeParse, currentLatitude, currentLongitude, currentTimeParse);
						double preprocessingDistance = PreprocFunction.getDistance(previousLatitude, previousLongitude, currentLatitude, currentLongitude);
						double preprocessingDirection = PreprocFunction.getDirection(previousLatitude, previousLongitude, currentLatitude, currentLongitude);

						Point preprocpoint = Point.measurement(AE)
								.time(currentTimeParse.getTime(), TimeUnit.MILLISECONDS)
								.addField("container", container)
								.addField("preprocessingSpeed", preprocessingSpeed)
								.addField("preprocessingDistance", preprocessingDistance)
								.addField("preprocessingDirection", preprocessingDirection)
								.build();

						batchPoints.point(preprocpoint);
						System.out.println("preprocpoint: "+ preprocpoint);
						System.out.println("[AE]: "+ AE + " Time: " + currentTimeParse
								+ "\n    -[Preprocessing]  Speed(m/s) "+ preprocessingSpeed + ", Distance(m): "+ preprocessingDistance + ", Direction: "+ preprocessingDirection);

						//logger.info("[AE]: "+ AE + "["+i+"] "+ "previousI: "+ previousI +" currentI: "+ currentI                             
						//		+ "\n    -[previousData]   Latitude: " + previousLatitude + " Longitude: " + previousLongitude + " Time: " + previousTimeParse
						//		+ "\n    -[currentData]     Latitude: " + currentLatitude + " Longitude: " + currentLongitude + " Time" + currentTimeParse
						//		+ "\n    -[Preprocessing]  Speed(m/s) "+ preprocessingSpeed + ", Distance(m): "+ preprocessingDistance + ", Direction: "+ preprocessingDirection);

						pipeline2.set("previous_"+AE, kafkaRecordConObject.toString());  

					}

					if(message_count >= 1000) {
						endP = System.currentTimeMillis();
						System.out.println("  [END] " + endP + " [" + threadName +"] >count: " + message_count);
						System.out.println( "Time taken(ms): " + ( endP - startP )); 
						//logger.info("[END] " + endP  + "[threadNum " + threadName + " ] count: " + message_count);
						//logger.info("Time taken(ms): " + ( endP - startP ));
					}

				}//for
				influxDB.write(batchPoints);

				kafkaRecords.clear();
				pipeline2.sync();
				jedis.close();

			}//while

		} catch (WakeupException e) {
			System.out.println(threadName + " trigger WakeupException");
		} finally {
			System.out.println(threadName + " gracefully shutdown");
			//consumer.close();
		}
	}

	public void shutdown() {
		consumer.wakeup();
	}

}