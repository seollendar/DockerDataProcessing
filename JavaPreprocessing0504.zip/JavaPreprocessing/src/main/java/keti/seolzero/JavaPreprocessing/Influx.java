package keti.seolzero.JavaPreprocessing;

import java.util.concurrent.TimeUnit;

import org.influxdb.InfluxDB;
import org.influxdb.InfluxDBFactory;
import org.influxdb.dto.Point;

public class Influx {

	static InfluxDB influxDB = InfluxDBFactory.connect("http://localhost:8086");
	static String dbName = "ssultest";


	public static void main(String[] args) {

		String AE = "st001";
		String container = "location";
		App conObject = new App();
		conObject.latitude = 10;
		conObject.longitude = 11;
		conObject.altitude = 12;
		saveToInflux(AE, container, conObject);

		System.out.println("DONE");
	}

	
	
	public static void saveToInflux(String AE, String container, Object conObject) {
		
			Point point2 = Point.measurement(AE)
					.addFieldsFromPOJO(conObject)
					.build();
			influxDB.write(dbName, "autogen", point2);
		
		
	}


}
