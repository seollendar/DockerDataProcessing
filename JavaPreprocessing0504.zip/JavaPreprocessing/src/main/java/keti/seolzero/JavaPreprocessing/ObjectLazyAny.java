package keti.seolzero.JavaPreprocessing;

import org.influxdb.annotation.Column;
import org.influxdb.annotation.TimeColumn;

public class ObjectLazyAny {
	@Column(name = "cnt")
	double container;
	
	@Column(name = "latitude")
	double latitude;

	@Column(name = "longitude")
	double longitude;

	@Column(name = "altitude")
	double altitude;

	@Column(name = "velocity")
	double velocity;

	@Column(name = "direction")
	int direction;

	@TimeColumn
	@Column(name = "time")
	long time;
}
