package keti.seolzero.JavaPreprocessing;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalDate;
import java.util.Properties;

public class JdbcPostgresqlConnection {
	private final String url = "jdbc:postgresql://localhost/spatiodata";
	private final String user = "postgres";
	private final String password = "keti123";
	
	public Connection connect() {
	    Connection conn = null;
	    try {
	        conn = DriverManager.getConnection(url, user, password);
	        System.out.println("Connected to the PostgreSQL server successfully.");

	    } catch (SQLException e) {
	        System.out.println(e.getMessage());
	    }

	    return conn;
	}


	public void createItem(String ae, String container, Double latitude, Double longitude, Double altitude, Double velocity, Double direction, String time) {
	    try {
	        Statement stmnt = null;
	        stmnt = connect().createStatement();
	        String sql = "INSERT INTO spatio (ae, container, latitude, longitude, altitude, velocity, direction, time, gps) "
	                + "VALUES " + "(" + ae + ", " + container + ", " + latitude + ", " + longitude 
	                + ", " + altitude + ", "  + velocity + ", " + direction + ", " + time + ", "
	                + "ST_SetSRID(ST_MakePoint(" + longitude + ", " + latitude + "),4326))"         
	                + ")";
	        System.out.println("sql: " + sql);
	        stmnt.executeUpdate(sql);

	    } catch (SQLException e) {
	        System.out.println(e.getMessage());
	    }

	}

	public static void main(String[] args) {;
		String ae ="ae";
		String container = "cnt-location";
		Double latitude = 37.411360;
		Double longitude = 127.129459;
		Double altitude = 3.3; 
		Double velocity = 4.4;
		Double direction = 5.5;
		String time = "2021-04-15T03:03:13.013";
	
		JdbcPostgresqlConnection Postgresql = new JdbcPostgresqlConnection();
		Postgresql.connect();
		Postgresql.createItem(ae, container, latitude, longitude, altitude, velocity, direction, time);

	}
}
