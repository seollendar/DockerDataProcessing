package keti.seolzero.JavaPreprocessing;


import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.apache.kafka.clients.consumer.ConsumerRecords;
import org.apache.kafka.clients.consumer.KafkaConsumer;
import org.apache.kafka.common.TopicPartition;
import org.apache.kafka.common.errors.WakeupException;
import org.apache.log4j.Logger;
import org.influxdb.dto.Point;

import com.jsoniter.JsonIterator;
import com.jsoniter.any.Any;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.Properties;
import java.util.TimeZone;
import java.util.concurrent.TimeUnit;
import java.text.ParseException;
import redis.clients.jedis.Jedis;
import redis.clients.jedis.JedisPool;
import redis.clients.jedis.JedisPoolConfig;
import redis.clients.jedis.Pipeline;
import org.influxdb.InfluxDB;
import org.influxdb.InfluxDBFactory;
import org.influxdb.dto.Point;



public class ConsumerWorkerInfluxDBtest implements Runnable {
	static InfluxDB influxDB = InfluxDBFactory.connect("http://localhost:8086");
	static String dbName = "consumer";
	
	private Properties prop;
	private String topic;
	private String threadName;
	private KafkaConsumer<String, String> consumer;
	
	private boolean flag = false;
	int message_count = 0;
	long startP, endP;

	ConsumerWorkerInfluxDBtest(Properties prop, String topic, int number) {
		this.prop = prop;
		this.topic = topic;
		this.threadName = "consumer-thread-" + number;
	}

	public void run() {
		consumer = new KafkaConsumer<String, String>(prop);
		consumer.subscribe(Arrays.asList(topic));

		try {
			System.out.println("== classify Module == "+ threadName +" ==");

			while (true) {

				ConsumerRecords<String, String> records = consumer.poll(100);

				for (ConsumerRecord<String, String> record : records) {
					Any jsonObject = JsonIterator.deserialize(record.value());
					Object conObject = jsonObject.get("m2m:sgn").get("nev").get("rep").get("m2m:cin").get("con");


					/* split device AE, container */
					String sur = jsonObject.get("m2m:sgn").get("sur").toString();
					String[] surSplitArray = sur.split("/");
					String AE = surSplitArray[4];        
					String container = surSplitArray[5]; 

					saveToInflux(AE, container, conObject);


				}//for

			}//while

		} catch (WakeupException e) {
			System.out.println(threadName + " trigger WakeupException");
		} finally {
			System.out.println(threadName + " gracefully shutdown");
			//consumer.close();
		}
	}

	public void shutdown() {
		consumer.wakeup();
	}


	public static void saveToInflux(String AE, String container, Object conObject) {
		
		SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS");
		format.setTimeZone(TimeZone.getTimeZone("UTC"));
		
		
		Double latitude = ((Any) conObject).get("latitude").toDouble();
		Double longitude = ((Any) conObject).get("longitude").toDouble();
		Double altitude = ((Any) conObject).get("altitude").toDouble();
		Double velocity = ((Any) conObject).get("velocity").toDouble();
		Double direction = ((Any) conObject).get("direction").toDouble();
		String timestamp = ((Any) conObject).get("time").toString();
		System.out.println("default: " + TimeZone.getTimeZone(timestamp));
		
		Date TimeParse = null;
		try {
			TimeParse = format.parse(timestamp);
		} catch (ParseException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		
		Point point1 = Point.measurement(AE)
				.addField("cnt", container)
				.addField("latitude", latitude)
				.addField("longitude", longitude)
				.addField("altitude", altitude)
				.addField("velocity", velocity)
				.addField("direction", direction)
				.time(TimeParse.getTime(), TimeUnit.MILLISECONDS)
				.build();
		
		Point pointForGrafana = Point.measurement("location")
				.addField("AE", AE)
				.addField("cnt", container)
				.addField("latitude", latitude)
				.addField("longitude", longitude)
				.addField("altitude", altitude)
				.addField("velocity", velocity)
				.addField("direction", direction)
				.time(TimeParse.getTime(), TimeUnit.MILLISECONDS)
				.build();
		
		influxDB.write(dbName, "autogen", point1);
		influxDB.write(dbName, "autogen", pointForGrafana);

	}



}