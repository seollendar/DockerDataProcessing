package keti.seolzero.JavaPreprocessing;

import java.util.HashMap;

import org.influxdb.annotation.Column;
import org.influxdb.annotation.Measurement;
import org.influxdb.annotation.TimeColumn;

import redis.clients.jedis.Jedis;
import redis.clients.jedis.JedisPool;
import redis.clients.jedis.JedisPoolConfig;

@Measurement(name = "AE")
public class App 
{
	@Column(name = "latitude")
   double latitude;
	
	@Column(name = "longitude")
   double longitude;
	
	@Column(name = "altitude")
   double altitude;
   
	@Column(name = "velocity")
   double velocity;
   
	@Column(name = "direction")
   int direction;
   
   @TimeColumn
   @Column(name = "time")
   long time;
   
}
